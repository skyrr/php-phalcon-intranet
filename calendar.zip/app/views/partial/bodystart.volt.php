
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="<?= $this->url->get('/') ?>" class="site_title"><img src="/assets/images/eLEDdesign-logo.svg" width="60" alt="..."> </a>
                    <!--<span>eLED Design.cz s.r.o.</span>-->
                </div>

                <div class="clearfix"></div>
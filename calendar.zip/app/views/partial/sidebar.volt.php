<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <br><br><br>
        <ul class="nav side-menu">
            <li><a><i class="fa fa-edit"></i> Scheduler <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?= $this->url->get('calendar1/index') ?>">1st floor</a></li>
                    <li><a href="<?= $this->url->get('calendar2/index') ?>">2nd floor</a></li>
                </ul>
            </li>
            </li>
        </ul>
    </div>
</div>

<!-- footer content -->
<footer>
    <div class="pull-right">
        <a href="http://http://www.eleddesign.cz/"> eLED DESIGN s.r.o. </a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->

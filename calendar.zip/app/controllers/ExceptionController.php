<?php
/**
 * Created by PhpStorm.
 * User: volodymyr
 * Date: 18.08.16
 * Time: 11:34
 */
class ExceptionController extends \Phalcon\Mvc\Controller
{
    public function notFoundAction()
    {

    }

    public function accessDeniedAction()
    {

    }
}
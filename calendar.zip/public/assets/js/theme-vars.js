

var color-green="#27cebc";
var color-blue="#00acec";
var color-yellow="#FDD01C";
var color-red="#f35958";
var color-grey="#dce0e8";
var color-black="#1b1e24";
var color-purple="#6d5eac";
var color-primary="#6d5eac";
var color-success="#4eb2f5";
var color-danger="#f35958";
var color-warning="#f7cf5e";
var color-info="#3b4751";

